import Navbar from "./Navbar.jsx";
import Section from "./Section.jsx";
import Footer from "./Footer.jsx";

export {
    Navbar,
    Section,
    Footer
}