const movies = [
  {
    id: 1,
    title: "How to Train Your Dragon",
    thumbnail: "https://media.themoviedb.org/t/p/w220_and_h330_face/q5pXRYTycaeW6dEgsCrd4mYPmxM.jpg",
    genre: "Fantasy",
  },
  {
    id: 2,
    title: "Night Carnage",
    thumbnail: "https://media.themoviedb.org/t/p/w220_and_h330_face/w0wjPQKhlqisSbylf1sWZiNyc2h.jpg",
    genre: "Thriller",
  },
   {
    id: 3,
    title: "Phantom",
    thumbnail: "https://media.themoviedb.org/t/p/w220_and_h330_face/n1rxZ4wovf7BYhLNwCqde8I3I2N.jpg",
    genre: "Fantasy",
  },
  {
    id: 4,
    title: "Guns Up",
    thumbnail: "https://media.themoviedb.org/t/p/w220_and_h330_face/3RokBWEkQqJRZEVP3DPwGm5MYh6.jpg",
    genre: "Thriller",
  },
   {
    id: 5,
    title: "Superman",
    thumbnail: "https://media.themoviedb.org/t/p/w300_and_h450_bestv2/qIegbn6DSUYmggfwxOBNOVS35q.jpg",
    genre: "Fantasy",
  },
  {
    id: 6,
    title: "Karate Kid: Legends",
    thumbnail: "https://media.themoviedb.org/t/p/w220_and_h330_face/AEgggzRr1vZCLY86MAp93li43z.jpg",
    genre: "Thriller",
  },
   {
    id: 7,
    title: "Ballerina",
    thumbnail: "https://media.themoviedb.org/t/p/w220_and_h330_face/2VUmvqsHb6cEtdfscEA6fqqVzLg.jpg",
    genre: "Fantasy",
  },
  {
    id: 8,
    title: "Happy Gilmore 2",
    thumbnail: "https://media.themoviedb.org/t/p/w220_and_h330_face/ynT06XivgBDkg7AtbDbX1dJeBGY.jpg",
    genre: "Thriller",
  },
   {
    id: 9,
    title: "Ice Road: Vengeance",
    thumbnail: "https://media.themoviedb.org/t/p/w220_and_h330_face/cQN9rZj06rXMVkk76UF1DfBAico.jpg",
    genre: "Fantasy",
  },
  {
    id: 10,
    title: "The Good, the Bad and the Ugly",
    thumbnail: "https://media.themoviedb.org/t/p/w220_and_h330_face/bX2xnavhMYjWDoZp1VM6VnU1xwe.jpg",
    genre: "Thriller",
  },
   
  // More movies...
];

export default movies;
