const tvshows = [

   {
    id: 5,
    title: "The Incredible Hulk",
    thumbnail: "https://media.themoviedb.org/t/p/w300_and_h450_bestv2/gKzYx79y0AQTL4UAk1cBQJ3nvrm.jpg",
    genre: "Fantasy",
  },
  {
    id: 6,
    title: "Spiderman",
    thumbnail: "https://media.themoviedb.org/t/p/w300_and_h450_bestv2/aGuvNAaaZuWXYQQ6N2v7DeuP6mB.jpg",
    genre: "Thriller",
  },
   {
    id: 7,
    title: "Arrow",
    thumbnail: "https://media.themoviedb.org/t/p/w220_and_h330_face/u8ZHFj1jC384JEkTt3vNg1DfWEb.jpg",
    genre: "Fantasy",
  },
  {
    id: 8,
    title: "Star Trek: Enterprise",
    thumbnail: "https://media.themoviedb.org/t/p/w220_and_h330_face/tsbBTABtNgu0ycsFpnIhiQ5woOM.jpg",
    genre: "Thriller",
  },
   {
    id: 9,
    title: "Good boy",
    thumbnail: "https://media.themoviedb.org/t/p/w220_and_h330_face/59MAdHaHepsz3uDCU1LyoNQcLlT.jpg",
    genre: "Fantasy",
  },
  {
    id: 10,
    title: "Miss Hammurabi",
    thumbnail: "https://media.themoviedb.org/t/p/w300_and_h450_bestv2/fa3lNbQQWIZw7zenNRuh4Nsu0ad.jpg",
    genre: "Thriller",
  },
    {
    id: 1,
    title: "Squid Game",
    thumbnail: "https://media.themoviedb.org/t/p/w220_and_h330_face/1QdXdRYfktUSONkl1oD5gc6Be0s.jpg",
    genre: "Fantasy",
  },
  {
    id: 2,
    title: "The Blacklist",
    thumbnail: "https://media.themoviedb.org/t/p/w220_and_h330_face/4HTfd1PhgFUenJxVuBDNdLmdr0c.jpg",
    genre: "Thriller",
  },
   {
    id: 3,
    title: "Dan Da Dan",
    thumbnail: "https://media.themoviedb.org/t/p/w220_and_h330_face/6qfZAOEUFIrbUH3JvePclx1nXzz.jpg",
    genre: "Fantasy",
  },
  {
    id: 4,
    title: "Lucifer",
    thumbnail: "https://media.themoviedb.org/t/p/w220_and_h330_face/ekZobS8isE6mA53RAiGDG93hBxL.jpg",
    genre: "Thriller",
  },
   
  // More movies...
];

export default tvshows;
