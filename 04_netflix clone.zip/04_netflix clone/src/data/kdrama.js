const kdramas = [
  {
    id: 1,
    title: "At Eighteen",
    thumbnail: "https://media.themoviedb.org/t/p/w300_and_h450_bestv2/AbEoQOZO6xnXg52Ehrd8aXchpLF.jpg",
    genre: "Fantasy",
  },
  {
    id: 2,
    title: "Come and Hug Me",
    thumbnail: "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/4IxIttWkGqa1RoISSpUdJhY1uOY.jpg",
    genre: "Thriller",
  },
   {
    id: 3,
    title: "Bring It On, Ghost",
    thumbnail: "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/wvhau2oaafT4xQgYknE6NP9j5Cl.jpg",
    genre: "Fantasy",
  },
  {
    id: 4,
    title: "More Than Friends",
    thumbnail: "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/mO1v6vDMQ7ZF8TilVAv5SOFyGGs.jpg",
    genre: "Thriller",
  },
   {
    id: 5,
    title: "Café Minamdang",
    thumbnail: "https://media.themoviedb.org/t/p/w300_and_h450_bestv2/jFXSdUd12KzpIKixEmTL0P7osxP.jpg",
    genre: "Fantasy",
  },
  {
    id: 6,
    title: "On Your Wedding Day ",
    thumbnail: "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/4b8Bytp4wqoxA9gNjh6V573ehwb.jpg",
    genre: "Thriller",
  },
   {
    id: 7,
    title: "Our Beloved Summer",
    thumbnail: "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/muWO0BvdYPw2nHvBAfQTjjD1XdF.jpg",
    genre: "Fantasy",
  },
  {
    id: 8,
    title: "Gyeongseong Creature",
    thumbnail: "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/1qxRfQq9BI9dZ1nOztEtTkqNgea.jpg",
    genre: "Thriller",
  },
   {
    id: 9,
    title: "Twinkling Watermelon",
    thumbnail: "https://media.themoviedb.org/t/p/w300_and_h450_bestv2/orfTfhGHPoCT0M9QT6g8ZjUpxTR.jpg",
    genre: "Fantasy",
  },
  {
    id: 10,
    title: "Why Her?",
    thumbnail: "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/A1gsw2kvpwQNocgyH4w3v6renbM.jpg",
    genre: "Thriller",
  },
  
];

export default kdramas