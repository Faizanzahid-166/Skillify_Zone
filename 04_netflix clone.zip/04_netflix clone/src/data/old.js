 const olds = [
 {
    id: 11,
    title: "18 again",
    thumbnail: "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/bHR7Qn23XnJsnyuUMQAy1r6DQ64.jpg",
    genre: "Thriller",
  },
  {
    id: 12,
    title: "Melting Me Softly",
    thumbnail: "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/i4drbygkN6MeVcZjaAeXXcP6syB.jpg",
    genre: "Thriller",
  },
  {
    id: 13,
    title: "Raib or shine",
    thumbnail: "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/w49EC9UhdMKBaD56TPGBaA6UcQ7.jpg",
    genre: "Thriller",
  },
    {
    id: 14,
    title: "My Man Is Cupid",
    thumbnail: "https://media.themoviedb.org/t/p/w300_and_h450_bestv2/ij2dlIzdEJa09Am7nxEoJbEjYcN.jpg",
    genre: "Thriller",
  },
    {
    id: 15,
    title: "Love Alarm",
    thumbnail: "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/s87JyAWtRLLlmsYWXTED1l8henB.jpg",
    genre: "Thriller",
  },
   {
    id: 16,
    title: "I Am Not a Robot",
    thumbnail: "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/yzr7b0Pa9bYmaleJ5coTO9Oqzwk.jpg",
    genre: "Thriller",
  },
    {
    id: 17,
    title: "Bloodhounds",
    thumbnail: "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/yu4oHDi6kO3cYXdmEnYT6SibATj.jpg",
    genre: "Thriller",
  },
   {
    id: 18,
    title: "Snowdrop",
    thumbnail: "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/xjpUY3OEDf2YBdNgedlew9Uj1z5.jpg",
    genre: "Thriller",
  },
    {
    id: 19,
    title: "Doctor Stranger",
    thumbnail: "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/odH9cebqUNHKh1p6BKVSs0gsD34.jpg",
    genre: "Thriller",
  },
   {
    id: 20,
    title: "Time",
    thumbnail: "https://www.themoviedb.org/t/p/w600_and_h900_bestv2/wioiG18yMZ8IIhl1PVi7LkkTWZq.jpg",
    genre: "Thriller",
  },
]

   
  // More movies...
  export default olds